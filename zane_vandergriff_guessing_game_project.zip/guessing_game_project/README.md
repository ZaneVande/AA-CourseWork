# AA-Inputs-Outputs

"This is an exercise in my online App Academy course under section "Inputs and Outputs"

"I'll be tasked with making a Guessing Game"